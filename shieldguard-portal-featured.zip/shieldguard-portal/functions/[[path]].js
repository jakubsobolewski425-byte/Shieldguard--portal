// Cloudflare Pages Function: render each /apps/<slug>/ page from the app catalog.
// Static assets are still served normally. This function makes app pages crawlable HTML.
const esc = s => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
export async function onRequest(context) {
 const url = new URL(context.request.url);
 if (!url.pathname.startsWith("/apps/")) return context.next();
 const slug = url.pathname.split("/").filter(Boolean)[1];
 if (!slug) return context.next();
 const response = await context.env.ASSETS.fetch(new Request(new URL("/assets/apps.js", url.origin)));
 if (!response.ok) return context.next();
 const js = await response.text();
 // apps.js is a trusted project-owned file; extract the static array in this project's format.
 let apps;
 try { apps = new Function(js.replace("window.SHIELDGUARD_APPS =", "return").replace(/;\s*$/, ""))(); }
 catch { return new Response("App catalog configuration error", {status:500}); }
 const app = apps.find(a => a.slug === slug);
 if (!app) return new Response("App not found", {status:404,headers:{"content-type":"text/plain; charset=utf-8"}});
 const canonical = `${url.origin}/apps/${encodeURIComponent(app.slug)}/`;
 const available = Boolean(app.downloadUrl) && app.status !== "Coming Soon";
 const download = available ? `<a class="button primary" href="${esc(app.downloadUrl)}" target="_blank" rel="noopener noreferrer">Download ↗</a>` : `<span class="button secondary" aria-label="Not yet available">Coming soon — not published</span>`;
 const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="${esc(app.description)}"><link rel="canonical" href="${canonical}"><link rel="stylesheet" href="/assets/style.css"><title>${esc(app.name)} | ShieldGuard Studio</title><meta property="og:title" content="${esc(app.name)} | ShieldGuard Studio"><meta property="og:description" content="${esc(app.description)}"><meta property="og:type" content="website"></head><body><header class="site-header"><a class="brand" href="/"><img src="/assets/logo.svg" alt="" width="42" height="42"><span>ShieldGuard <small>STUDIO</small></span></a><nav><a href="/#apps">All apps</a><a href="/contact/">Contact</a><a href="https://tipply.pl/@kajzerkagg">♥ Support</a></nav></header><main class="page-content"><div class="app-icon">${esc(app.icon)}</div><p><span class="status ${app.status==="Coming Soon"?"coming-soon":""}">${esc(app.status)}</span></p><h1>${esc(app.name)}</h1><p>${esc(app.description)}</p><p class="muted">Platforms: ${esc(app.platform)} · Version: ${esc(app.version)}</p><div class="hero-actions" style="justify-content:flex-start">${download}<a class="button secondary" href="https://tipply.pl/@kajzerkagg" target="_blank" rel="noopener noreferrer">♥ Support on Tipply</a></div><h2>Features</h2><ul>${app.features.map(x=>`<li>${esc(x)}</li>`).join("")}</ul><h2>Screenshots</h2><p class="muted">${app.screenshots.length ? "Screenshots will be added here." : "Screenshots will be published when available."}</p><div class="notice">Release status: ${esc(app.status)}. This page is informational; no download is offered until an official file or store listing is configured.</div><p><a href="/#apps">← Back to all apps</a></p></main><footer class="site-footer"><div class="footer-links"><a href="/about/">About</a><a href="/contact/">Contact</a><a href="/terms/">Terms</a><a href="/privacy/">Privacy</a></div><div class="ad-slot"><span>ADVERTISEMENT</span><div>Ad space — connect your approved Google AdSense account.</div></div><div class="footer-bottom">© ${new Date().getFullYear()} ShieldGuard Studio</div></footer></body></html>`;
 return new Response(html,{headers:{"content-type":"text/html; charset=utf-8","cache-control":"public, max-age=300"}});
}