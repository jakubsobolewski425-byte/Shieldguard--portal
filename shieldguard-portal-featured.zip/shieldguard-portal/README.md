# ShieldGuard Studio portal

A responsive static apps portal for Cloudflare Pages. Includes app catalogue, SEO-friendly per-app pages via a Pages Function, support modal, Tipply links, legal-page drafts, and a clearly marked AdSense placeholder.

## Publish on Cloudflare Pages

1. Replace `YOUR-PROJECT.pages.dev` in `index.html`, `robots.txt`, and `sitemap.xml` with the final project hostname.
2. Replace `YOUR_EMAIL@example.com` and the legal operator placeholders in contact and legal pages.
3. Edit `assets/apps.js` to add real projects. Keep `status: "Coming Soon"` and `downloadUrl: ""` until the app is actually published. Only add an official HTTPS download URL when ready.
4. Create a Cloudflare account and open Workers & Pages → Create application → Pages.
5. Choose **Connect to Git** (recommended because the app pages use a Pages Function), or use Wrangler CLI. Upload-only Direct Upload projects do not support Pages Functions in the same way; use Git integration or deploy with Wrangler.
6. For Git: create a repository, add these files, push them, then connect the repository in Cloudflare Pages. Framework preset: None. Build command: leave blank. Build output directory: `/` (or the repository root as accepted by the current dashboard).
7. Deploy and test `/`, `/apps/shieldguard/`, `/terms/`, and `/privacy/`.

## AdSense

The ad slots are placeholders, not live ads. Apply to AdSense and wait for approval. Once approved, follow Google's current instructions to add the publisher script and ad units. Put your real publisher ID in the script; never copy a random ID. Create an `ads.txt` file only with the exact line Google provides for your account. For visitors in the EEA, configure a Google-certified consent management platform and valid consent where required before serving personalized ads.

## Real visitor analytics

The displayed counts are local browser demo counters only. They are not global and can be reset by visitors. To get actual aggregate visits, enable Cloudflare Web Analytics in the Cloudflare dashboard and insert the exact beacon snippet Cloudflare supplies. Track downloads with a server-side endpoint or analytics event if you need trustworthy aggregate download counts.

## Payments / support

This version uses Tipply only. The support link is external and optional; it is not a checkout system hosted on this website.

## Legal and security

Terms and privacy pages are drafts. Replace placeholders and adapt them to the actual operator, hosting, analytics, advertising, and data practices before launch. The contact page is a static email link, not a working form backend.
