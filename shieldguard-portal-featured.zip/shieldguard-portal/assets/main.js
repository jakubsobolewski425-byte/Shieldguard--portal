(() => {
 const apps=window.SHIELDGUARD_APPS||[];
 const grid=document.getElementById("app-grid");
 const search=document.getElementById("search");
 const modal=document.getElementById("support-modal");
 const confirm=document.getElementById("confirm-download");
 const desc=document.getElementById("modal-description");
 const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
 const statusClass=s=>s==="Coming Soon"?"coming-soon":s==="Beta"?"beta":"";
 function render(query=""){
  if(!grid)return;
  const list=apps.filter(a=>(a.name+" "+a.description+" "+a.platform).toLowerCase().includes(query.toLowerCase()));
  grid.innerHTML=list.map(a=>`<article class="app-card"><div class="app-card-top"><div class="app-icon" aria-hidden="true">${esc(a.icon)}</div><span class="status ${statusClass(a.status)}">${esc(a.status)}</span></div><h3>${esc(a.name)}</h3><p>${esc(a.description)}</p><div class="platform">${esc(a.platform)}</div><a class="button ${a.status==="Coming Soon"?"secondary":"primary"}" href="/apps/${encodeURIComponent(a.slug)}/">${a.status==="Coming Soon"?"View project":"View app"} ↗</a></article>`).join("");
  const empty=document.getElementById("empty-state");if(empty)empty.classList.toggle("hidden",list.length!==0);
 }
 render();if(search)search.addEventListener("input",e=>render(e.target.value));
 document.querySelectorAll("[data-download]").forEach(btn=>btn.addEventListener("click",()=>openDownload(btn.dataset.download)));
 function openDownload(slug){
  const app=apps.find(a=>a.slug===slug);if(!app)return;
  if(!app.downloadUrl){desc.textContent="This project is not published yet. Its status is Coming Soon, so there is no official download available.";confirm.textContent="View project status";confirm.href="/apps/"+encodeURIComponent(slug)+"/";confirm.onclick=null;}
  else {desc.textContent="Continue to the official download for "+app.name+", or optionally support future development.";confirm.textContent="Continue to download";confirm.href=app.downloadUrl;confirm.target="_blank";confirm.rel="noopener noreferrer";confirm.onclick=()=>count("downloads");}
  modal.classList.add("open");modal.setAttribute("aria-hidden","false");
 }
 document.querySelectorAll("[data-close]").forEach(el=>el.addEventListener("click",()=>{modal.classList.remove("open");modal.setAttribute("aria-hidden","true")}));
 document.addEventListener("keydown",e=>{if(e.key==="Escape"&&modal){modal.classList.remove("open");modal.setAttribute("aria-hidden","true")}});
 function count(key){try{const k="sg_"+key;localStorage.setItem(k,String((Number(localStorage.getItem(k))||0)+1));updateStats()}catch(e){}}
 function updateStats(){try{const v=Number(localStorage.getItem("sg_visits"))||0,d=Number(localStorage.getItem("sg_downloads"))||0;const ve=document.getElementById("local-visits"),de=document.getElementById("local-downloads");if(ve)ve.textContent=v.toLocaleString();if(de)de.textContent=d.toLocaleString()}catch(e){}}
 if(document.getElementById("year"))document.getElementById("year").textContent=new Date().getFullYear();
 if(document.getElementById("local-visits")){try{if(!sessionStorage.getItem("sg_session_seen")){count("visits");sessionStorage.setItem("sg_session_seen","1")}}catch(e){}updateStats()}
})();